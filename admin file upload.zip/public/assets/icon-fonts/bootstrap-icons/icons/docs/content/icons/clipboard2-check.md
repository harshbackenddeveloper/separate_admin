---
title: Clipboard2 check
categories:
  - Real world
tags:
  - copy
  - paste
---
